#ifndef CIVETWEB_CONF_H
#define CIVETWEB_CONF_H

#define USE_IPV6 1

#endif
