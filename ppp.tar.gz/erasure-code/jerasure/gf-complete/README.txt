This is GF-Complete, Revision 1.02.   January 1, 2014.

Authors: James S. Plank (University of Tennessee)
         Ethan L. Miller (UC Santa Cruz)
         Kevin M. Greenan (Box)
         Benjamin A. Arnold (University of Tennessee)
         John A. Burnum (University of Tennessee)
         Adam W. Disney (University of Tennessee,
         Allen C. McBride (University of Tennessee)

The user's manual is in the file Manual.pdf.  You may also get a copy of that
manual at http://www.cs.utk.edu/~plank/plank/papers/GF-Complete-Manual-1.02.pdf.

The online home for GF-Complete is:

  - https://bitbucket.org/jimplank/gf-complete

If you want to cite GF-Complete in a paper, I suggest citing the
technical report version.  The precise citation information for that
is in http://www.cs.utk.edu/~plank/plank/papers/CS-13-716.html.

To compile, do:

   ./configure
   make
   sudo make install
